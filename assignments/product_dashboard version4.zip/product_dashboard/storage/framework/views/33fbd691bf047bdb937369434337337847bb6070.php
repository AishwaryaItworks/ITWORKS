
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-3.4.1.js"></script> 
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.js"></script>
<script src=<?php echo e(asset('frontend/plugins/bower_components/jquery/dist/jquery.min.js')); ?>></script>
<!-- Bootstrap tether Core JavaScript -->
<script src=<?php echo e(asset('frontend/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>></script>
<script src=<?php echo e(asset('frontend/js/app-style-switcher.js')); ?>></script>

<!--Wave Effects -->
<script src=<?php echo e(asset('frontend/js/waves.js')); ?>></script>
<!--Menu sidebar -->
<script src=<?php echo e(asset('frontend/js/sidebarmenu.js')); ?>></script>
<!--Custom JavaScript -->
<script src=<?php echo e(asset('frontend/js/custom.js')); ?>></script>
<!--This page JavaScript -->



<?php echo jquery(); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\product_dashboard\resources\views/layouts/footer.blade.php ENDPATH**/ ?>