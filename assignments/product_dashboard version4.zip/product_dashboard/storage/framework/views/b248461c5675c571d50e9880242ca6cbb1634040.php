
<?php $__env->startSection('main-section'); ?>
<script>
    $(document).ready(function(){
        $('#Table').DataTable();
    });
</script>
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Product</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <ol class="breadcrumb ms-auto">
                                <li><a href="/Product" class="btn btn-primary"><b>Add Product</b></a></li>
                            </ol>
                            
                        </div>
                   </div>     
        </div>          
    </div>
        
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Products</div>

                <div class="card-body">
                    <table class="table table-bordered datatable" id="Table">
                        <thead class="table-dark">
                            
                            
                            <td>Product Name</td>
                            <td>Category Description</td>
                            <td>Status</td>
                            <td>Created time</td>
                            <td>Image</td>
                            <td>Category name</td>
                            <td>SubCategory name</td>
                            <td>Action</td>
                        </thead>
                        <tbody>
                            
                        <?php if($products->isNotEmpty()): ?> 
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    
                                    <td><?php echo e($product->product_category_name); ?></td>
                                    <td><?php echo e($product->product_category_description); ?></td>

                                    <?php if($product->product_category_status=='Active'): ?>         
                                   <td><a href='<?php echo e(url('/changestatus',$product->product_category_id)); ?>' class="btn btn-success">Active</a></td>         
                                    <?php else: ?>
                                        <td><a href='<?php echo e(url('/changestatus',$product->product_category_id)); ?>' class="btn btn-danger">Inactive</a></td>        
                                    <?php endif; ?>
                                    

                                    
                                    
                                    <td><?php echo e($product->created_at); ?></td>
                                    
                                    <td>
                                        <img src="<?php echo e(asset('Uploads/'.$product->product_image)); ?>" width="70px" height="70px" alt="Image">
                                    </td>
                                    <td><?php echo e($product->category_name); ?></td>
                                    <td><?php echo e($product->subcategory_name); ?></td>
                                    <td><a href="<?php echo e(url('Product/edit')); ?>/<?php echo e($product->product_category_id); ?>" class="btn btn-primary">Update</a>
                                        <button type="button" class="btn btn-danger deletebtn" id="" value="<?php echo e($product->product_category_id); ?>">Delete</button>

                                        
                                    
                                       
                                        
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>

                        
                    </table>
       
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Delete Product</h5>
            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
          <form action="<?php echo e(url('Product/delete')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
                
                <div class="modal-body">
                    <h5>Do You Want to delete?</h5>
                    <input type="hidden" name="product_category_id" id="product_category_id">
                
                </div>
                <div class="modal-footer">
                
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-danger">Yes Delete</button>
                </div>
            </form>
      </div>
    </div>
</div>



<script>
    $(document).ready(function(){
        $(document).on('click','.deletebtn',function(){

            var id=$(this).val();
            $('#deleteModal').modal('show');
            $('#product_category_id').val(id);
        });

        $(document).on('change','.btndel',function(){

          var id=$(this).val();
          alert(id);
          $('#dataModal').modal('show');
          $('#product_category_id').val(id);
          });

    
    
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\product_dashboard\resources\views/product_list.blade.php ENDPATH**/ ?>