
<?php $__env->startSection('main-section'); ?>
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <h4 class="page-title">Products</h4>
                <br>
            </div>
            <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                <div class="d-md-flex">
                    <ol class="breadcrumb ms-auto">
                        
                    </ol>
                    
                </div>
            </div>
            
        </div>

        <form action="<?php echo e(url('Product/store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
            <label>Product Name</label>
            <input type="text" class="form-control" name="product_category_name" value="<?php echo e(old('product_category_name')); ?>">
            <small class="text-danger"><?php echo e($errors->first('product_category_name')); ?></small>
            </div>

            <div class="form-group">
                <label>Product Description</label>
                <textarea class="form-control" name="product_category_description"></textarea>
            </div>

            <div class="form-group">
                <input id="DateTime" name="DateTime" type="hidden" value="">
            </div>

            <div class="form-group">
                <label>Product Image</label>
                <input type="file" class="form-control" name="product_image" value="<?php echo e(old('product_image')); ?>">
                <button type="submit" class="btn btn-primary btn-sm float-end">Upload File</button>
                <small class="text-danger"><?php echo e($errors->first('product_image')); ?></small>
            </div>

            <div class="form-group">
                <label>Select Category</label>
                <select name="category_id" class="form-control" id="category">
                    <option value="">Select name</option>
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->category_id); ?>"><?php echo e($category->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
 
            


            <div class="form-group">
                <label>Select SubCategory</label>
                <select name="subcategory_id" class="form-control" id="sub">
                    <option value="">Select name</option>
                    <?php $__currentLoopData = $product2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->subcategory_id); ?>"><?php echo e($category->subcategory_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-primary" name="submit" value="Add Product">
            </div>


        </form>
        
    </div>
</div>





<script src="http://code.jquery.com/jquery-3.4.1.js"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>




<script>
    jQuery(document).ready(function(){
      jQuery('#category').change(function(){
        let cid=jQuery(this).val();
        jQuery('#sub').html(' <option value="">Select name</option>');
        //alert(cid);
         jQuery.ajax({
           url:'/get_Sub_Category/'+cid,
          type:'get',
           data:'cid='+cid +'$_token=<?php echo e(csrf_token()); ?>',
          //datatype:'json',
          success:function(result){
            jQuery('#sub').html(result);
          }
        }); 
      });
    });
  </script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.1/moment.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
      var today = moment().format('YYYY-MM-DD HH:mm:ss');
      $('#DateTime').val(today);
     // alert($('#DateTime').val());
    });
  </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\product_dashboard\resources\views//Product.blade.php ENDPATH**/ ?>