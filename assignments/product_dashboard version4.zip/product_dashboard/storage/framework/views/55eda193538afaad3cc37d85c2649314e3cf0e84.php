

<?php $__env->startSection('main-section'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Category</div>

                <div class="card-body">
                    <form action="<?php echo e(url('category/update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="category_id" value="<?php echo e($product->category_id); ?>">
                        <div class="form-group">
                        <label>Product Category Name</label>
                        <input type="text" class="form-control" name="category_name" value="<?php echo e($product->category_name); ?>">
                        <small class="text-danger"><?php echo e($errors->first('category_name')); ?></small>
                        </div>

                        
                        <div class="form-group">
                            <input type="submit" class="btn btn-primary" name="submit" value="Update">
                        </div>
    

                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\product_dashboard\resources\views/edit_category.blade.php ENDPATH**/ ?>