

<?php $__env->startSection('main-section'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Category</div>

                <div class="card-body">
                    <form action="<?php echo e(url('subcategory/update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="subcategory_id" value="<?php echo e($product->subcategory_id); ?>">
                        <div class="form-group">
                        <label>Product Category Name</label>
                        <input type="text" class="form-control" name="subcategory_name" value="<?php echo e($product->subcategory_name); ?>">
                        <small class="text-danger"><?php echo e($errors->first('subcategory_name')); ?></small>
                        </div>

                        
                        <div class="form-group">
                            <input type="submit" class="btn btn-primary" name="submit" value="Update">
                        </div>
    

                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\product_dashboard\resources\views/edit_subcategory.blade.php ENDPATH**/ ?>