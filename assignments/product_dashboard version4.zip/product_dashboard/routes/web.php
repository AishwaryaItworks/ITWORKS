<?php

use Illuminate\Support\Facades\Route;
use App\Models\productcontroller;
use App\Models\ProductListController;
use App\Models\categoryController;
use App\Models\subcategoryController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/Product', [App\Http\Controllers\productcontroller::class, 'index']);
Route::get('/Product/{id}', [App\Http\Controllers\productcontroller::class, 'get']);


Route::get('/category', [App\Http\Controllers\categoryController::class, 'index']);

// Route::get('/product_list', [App\Http\Controllers\productcontroller::class, 'index']);

// Route::get('/product_list', [App\Http\Controllers\ProductListController::class, 'index']);
Route::get('/product_list', [App\Http\Controllers\productcontroller::class, 'show_table']);
Route::post('/Product/store', [App\Http\Controllers\productcontroller::class, 'store']);

Route::get('/category_list', [App\Http\Controllers\categorycontroller::class, 'show_table']);
Route::post('/category/store', [App\Http\Controllers\categoryController::class, 'store']);

Route::get('/category/delete/{id}', [App\Http\Controllers\categoryController::class, 'destroy']);

Route::get('/category/edit/{id}', [App\Http\Controllers\categoryController::class, 'edit']);

Route::post('/category/update', [App\Http\Controllers\categoryController::class, 'update']);
////
Route::delete('/Product/delete', [App\Http\Controllers\productcontroller::class, 'destroy']);

Route::get('/Product/edit/{id}', [App\Http\Controllers\productcontroller::class, 'edit']);

Route::post('/Product/update', [App\Http\Controllers\productcontroller::class, 'update']);



Route::get('/get_Sub_Category/{id}', [App\Http\Controllers\productcontroller::class, 'get_Sub_Category']);

Route::get('/changestatus/{id}', [App\Http\Controllers\productcontroller::class, 'changestatus']);

Route::get('/subcategory', [App\Http\Controllers\subcategoryController::class, 'index']);
Route::get('/subcategory_list', [App\Http\Controllers\subcategoryController::class, 'show_table']);

Route::post('/subcategory/store', [App\Http\Controllers\subcategoryController::class, 'store']);
Route::get('/subcategory/edit/{id}', [App\Http\Controllers\subcategoryController::class, 'edit']);


Route::post('/subcategory/update', [App\Http\Controllers\subcategoryController::class, 'update']);



Route::get('/subcategory/edit{id}', [App\Http\Controllers\subcategoryController::class, 'edit']);

Route::post('/subcategory/delete{id}', [App\Http\Controllers\subcategoryController::class, 'destroy']);


