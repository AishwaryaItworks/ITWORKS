<?php

namespace App\Http\Controllers;

use App\Models\category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use App\Models\product;
use App\Models\Subcategory;
use App\Traits;
use App\Traits\CommonTrait;

class productcontroller extends Controller
{
    //
    use CommonTrait;
    public function index(){
        //$time=$this->getindex();
        $product=category::get();

        //$outputs = Subcategory::pluck('name', 'id');
        $product2=Subcategory::get();
        //dd($product);
        return view('/Product',compact('product','product2'));
    }


    public function store(Request $request)
    {
           // $values=$request->all();

            //for validation
            $this->validate($request,[
                'product_category_name'=>'required'
                
            ]);
            //end of validation
            $product=new product;
            $product->product_category_name=$request->input('product_category_name');
            $product->product_category_description=$request->input('product_category_description');
           
            //for join two table
            
            //end of join
           
            if($request->hasfile('product_image'))
            {
            $filename=time().".".$request->file('product_image')->getClientOriginalExtension();
            $request->file('product_image')->move('uploads',$filename);
            // $values['product_image'] = $filename;
           $product->product_image=$filename;
            }
            //$product->product_category_status=$request->product_category_status;
            $product->category_id=$request->input('category_id');
            $product->subcategory_id=$request->input('subcategory_id');
            $product->created_at=$request->input('DateTime');

            $product->save();
            //$product=product::create($values);
            if($product)
            {
                toastr()->success('Record is added');
                return redirect('/product_list');
            }
    }


    public function get_Sub_Category($id){
        //$id=$request->get('cid');
        $sub_category= Subcategory::where('category_id',$id)->get();
      
        $html='<option value="">Select name</option>';
        foreach($sub_category as $sub_categories){
            $html.='<option value=" '.$sub_categories->subcategory_id.' ">'.$sub_categories->subcategory_name.'</option>';
        }
        echo $html;
    }

    public function changestatus($id){
        //Select Query
        $product=Product::findorfail($id);
       // dd($member);
        if($product->product_category_status=='Active'){
            toastr()->error('Status Changed to Inactive');
            $product->product_category_status ='Inactive';
            
        }
        else{
            toastr()->success('Status Changed to Active');
            $product->product_category_status ='Active';
            
        }
       
        $product->update();
        return redirect('product_list');
        
    }

    public function show_table(){

        $products = Product::join('subcategories', 'subcategories.subcategory_id', '=', 'products.subcategory_id')
              		->join('categories', 'categories.category_id', '=', 'subcategories.category_id')
              		->get();
        //$products = product::join('categories','categories.category_id','products.category_id')->get();
        
        //$products = Product::with('getcategory')->get();
        //$products=product::get();
        return view('product_list',compact('products'));
    }

    public function edit($id)
    {
        $product=product::findorfail($id);
        return view('edit_product',compact('product'));
    }

    public function update(Request $request)
    {
        $input=$request->all();
        $searchInput['product_category_id']=$input['product_category_id'];
        product::updateorcreate($searchInput,$input);
        toastr()->success('Record is updated');
        return redirect('/product_list');

    }


    public function destroy(Request $request)
    {
        $cat_id=$request->input('product_category_id');
        $product=product::find($cat_id);
        $destination='uploads/'.$product->product_image;
        
        //unlink($destination);
        if(File::exists($destination))
        {
            File::delete($destination);
        }
         $product->delete();
        // product::where('product_category_id',$cat_id)->delete();
        toastr()->error('Record is deleted');
        return redirect('/product_list');
        // dd($id);
    }

    // public function destroy($id)
    // {
    //     $product=product::find($id);
    //     $destination='uploads/'.$product->product_image;
    //     //unlink($destination);
    //     if(File::exists($destination))
    //     {
    //         File::delete($destination);
    //     }
    //     $product->delete();
    //     //product::where('product_category_id',$id)->delete();
    //     toastr()->error('Record is deleted');
    //     return redirect('/product_list');
    //     // dd($id);
    // }
}
