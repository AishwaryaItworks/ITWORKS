<?php
namespace App\Traits;
use App\Models\category;
use Carbon\Carbon;

trait CommonTrait {
    // public function getCategory($category_id) {
    //     $category = category::where('category_id',$category_id)->first();
    //     return $category;
    // }

    public function getindex(){
        $date_time=Carbon::now();
        //date_default_timezone_set("Asia/Kolkata");
        echo $date_time;
    }
    
}
?>