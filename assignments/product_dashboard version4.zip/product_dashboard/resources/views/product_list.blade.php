@extends('layouts.main')
@section('main-section')
<script>
    $(document).ready(function(){
        $('#Table').DataTable();
    });
</script>
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Product</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <ol class="breadcrumb ms-auto">
                                <li><a href="/Product" class="btn btn-primary"><b>Add Product</b></a></li>
                            </ol>
                            {{-- <a href="https://www.wrappixel.com/templates/ampleadmin/" target="_blank"
                                class="btn btn-danger  d-none d-md-block pull-right ms-3 hidden-xs hidden-sm waves-effect waves-light text-white">Upgrade
                                to Pro</a> --}}
                        </div>
                   </div>     
        </div>          
    </div>
        
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Products</div>

                <div class="card-body">
                    <table class="table table-bordered datatable" id="Table">
                        <thead class="table-dark">
                            {{-- <td>Category_Id</td> --}}
                            
                            <td>Product Name</td>
                            <td>Category Description</td>
                            <td>Status</td>
                            <td>Created time</td>
                            <td>Image</td>
                            <td>Category name</td>
                            <td>SubCategory name</td>
                            <td>Action</td>
                        </thead>
                        <tbody>
                            
                        @if($products->isNotEmpty()) 
                                @foreach($products as $product)
                                <tr>
                                    {{-- <td>{{$product->product_category_id}}</td> --}}
                                    <td>{{$product->product_category_name}}</td>
                                    <td>{{$product->product_category_description}}</td>

                                    @if($product->product_category_status=='Active')         
                                   <td><a href='{{url('/changestatus',$product->product_category_id)}}' class="btn btn-success">Active</a></td>         
                                    @else
                                        <td><a href='{{url('/changestatus',$product->product_category_id)}}' class="btn btn-danger">Inactive</a></td>        
                                    @endif
                                    

                                    {{-- <input data-id="{{$product->product_category_id}}" class="toggle-class btndel" type="checkbox" data-onstyle="success"
                                        data-offstyle="danger" data-toggle="toggle" data-on="Active" data-off="Inactive"
                                        {{$product->product_category_status ? 'checked':''}}> --}}
                                    {{-- <td>{{$product->product_category_status}}</td> --}}
                                    <td>{{$product->created_at}}</td>
                                    
                                    <td>
                                        <img src="{{asset('Uploads/'.$product->product_image)}}" width="70px" height="70px" alt="Image">
                                    </td>
                                    <td>{{$product->category_name}}</td>
                                    <td>{{$product->subcategory_name}}</td>
                                    <td><a href="{{url('Product/edit')}}/{{$product->product_category_id}}" class="btn btn-primary">Update</a>
                                        <button type="button" class="btn btn-danger deletebtn" id="" value="{{$product->product_category_id}}">Delete</button>

                                        {{-- Old one delete <a href="{{url('Product/delete')}}/{{$product->product_category_id}}" class="btn btn-danger deletebtn">Delete</a> --}}
                                    
                                       
                                        {{-- <a class="btn btn-danger deletebtn" href="{{$product->product_category_id}}" data-toggle="tooltip" data-id="1" data-original-title="Delete">Delete</a> --}}
                                        
                                    </td>
                                </tr>
                                @endforeach
                            @endif
                        </tbody>

                        
                    </table>
       
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Delete Product</h5>
            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
          <form action="{{url('Product/delete')}}" method="post">
              @csrf
              @method('DELETE')
                
                <div class="modal-body">
                    <h5>Do You Want to delete?</h5>
                    <input type="hidden" name="product_category_id" id="product_category_id">
                
                </div>
                <div class="modal-footer">
                
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-danger">Yes Delete</button>
                </div>
            </form>
      </div>
    </div>
</div>



<script>
    $(document).ready(function(){
        $(document).on('click','.deletebtn',function(){

            var id=$(this).val();
            $('#deleteModal').modal('show');
            $('#product_category_id').val(id);
        });

        $(document).on('change','.btndel',function(){

          var id=$(this).val();
          alert(id);
          $('#dataModal').modal('show');
          $('#product_category_id').val(id);
          });

    
    
    });
</script>
@endsection