@extends('layouts.main')
@section('main-section')
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <h4 class="page-title">Products</h4>
                <br>
            </div>
            <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                <div class="d-md-flex">
                    <ol class="breadcrumb ms-auto">
                        {{-- <li><a href="#" class="fw-normal">Dashboard</a></li> --}}
                    </ol>
                    {{-- <a href="{{url('/product_list')}}" target="_blank"
                        class="btn btn-danger  d-none d-md-block pull-right ms-3 hidden-xs hidden-sm waves-effect waves-light text-white">
                        View List of Product</a> --}}
                </div>
            </div>
            
        </div>

        <form action="{{url('Product/store')}}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
            <label>Product Name</label>
            <input type="text" class="form-control" name="product_category_name" value="{{old('product_category_name')}}">
            <small class="text-danger">{{$errors->first('product_category_name')}}</small>
            </div>

            <div class="form-group">
                <label>Product Description</label>
                <textarea class="form-control" name="product_category_description"></textarea>
            </div>

            <div class="form-group">
                <input id="DateTime" name="DateTime" type="hidden" value="">
            </div>

            <div class="form-group">
                <label>Product Image</label>
                <input type="file" class="form-control" name="product_image" value="{{old('product_image')}}">
                <button type="submit" class="btn btn-primary btn-sm float-end">Upload File</button>
                <small class="text-danger">{{$errors->first('product_image')}}</small>
            </div>

            <div class="form-group">
                <label>Select Category</label>
                <select name="category_id" class="form-control" id="category">
                    <option value="">Select name</option>
                    @foreach($product as $category)
                    <option value="{{$category->category_id}}">{{$category->category_name}}</option>
                    @endforeach
                </select>
            </div>
 
            


            <div class="form-group">
                <label>Select SubCategory</label>
                <select name="subcategory_id" class="form-control" id="sub">
                    <option value="">Select name</option>
                    @foreach($product2 as $category)
                    <option value="{{$category->subcategory_id}}">{{$category->subcategory_name}}</option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-primary" name="submit" value="Add Product">
            </div>


        </form>
        
    </div>
</div>

{{-- <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

 --}}



<script src="http://code.jquery.com/jquery-3.4.1.js"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>




<script>
    jQuery(document).ready(function(){
      jQuery('#category').change(function(){
        let cid=jQuery(this).val();
        jQuery('#sub').html(' <option value="">Select name</option>');
        //alert(cid);
         jQuery.ajax({
           url:'/get_Sub_Category/'+cid,
          type:'get',
           data:'cid='+cid +'$_token={{csrf_token() }}',
          //datatype:'json',
          success:function(result){
            jQuery('#sub').html(result);
          }
        }); 
      });
    });
  </script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.1/moment.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
      var today = moment().format('YYYY-MM-DD HH:mm:ss');
      $('#DateTime').val(today);
     // alert($('#DateTime').val());
    });
  </script>


@endsection