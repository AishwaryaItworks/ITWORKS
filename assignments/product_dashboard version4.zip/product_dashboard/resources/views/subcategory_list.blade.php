@extends('layouts.main')
@section('main-section')
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">SubCategory</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <ol class="breadcrumb ms-auto">
                                <li><a href="/subcategory" class="btn btn-primary"><b>Add Subcategory</b></a></li>
                            </ol>
                            {{-- <a href="https://www.wrappixel.com/templates/ampleadmin/" target="_blank"
                                class="btn btn-danger  d-none d-md-block pull-right ms-3 hidden-xs hidden-sm waves-effect waves-light text-white">Upgrade
                                to Pro</a> --}}
                        </div>
                    </div>
                    
        </div>         
    </div>
        <div class="col-md-8">
            <div class="card">
                {{-- <div class="card-header">Category</div> --}}

                <div class="card-body">
                    <table class="table">
                        <thead class="table-dark">
                            <td>Category_Name</td>
                            <td>SubCategory_Name</td>
                            <td>Action</td>
                        </thead>
                        <tbody>
                        @if($produc->isNotEmpty()) 
                                @foreach($produc as $product)
                                <tr>
                                    {{-- <td>{{$product->product_category_id}}</td> --}}
                                    <td>{{$product->category_name}}</td>
                                    <td>{{$product->subcategory_name}}</td>

                                    <td><a href="{{url('subcategory/edit')}}/{{$product->subcategory_id}}" class="btn btn-primary">Update</a>
                                        <a href="{{url('subcategory/delete')}}/{{$product->subcategory_id}}" class="btn btn-danger">Delete</a></td>
                                    
                                </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                
                </div>
            </div>
        </div>
    
</div>
</div>
@endsection