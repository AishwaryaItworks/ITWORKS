@extends('layouts.main')

@section('main-section')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Products</div>

                <div class="card-body">
                    <form action="{{url('Product/update')}}" method="post">
                        @csrf
                        <input type="hidden" name="product_category_id" value="{{$product->product_category_id}}">
                        <div class="form-group">
                        <label>Product Category Name</label>
                        <input type="text" class="form-control" name="product_category_name" value="{{$product->product_category_name}}">
                        <small class="text-danger">{{$errors->first('product_category_name')}}</small>
                        </div>

                        <div class="form-group">
                            <label>Product Description</label>
                            <textarea class="form-control" name="product_category_description" value="{{$product->product_category_description}}"></textarea>
                        </div>

                        <div class="form-group">
                            <label>Product Image</label>
                            <input type="file" class="form-control" name="product_image" value="{{old('product_image')}}">
                            <button type="submit" class="btn btn-primary btn-sm float-end">Upload File</button>
                            <small class="text-danger">{{$errors->first('product_image')}}</small>
                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-primary" name="submit" value="Update">
                        </div>
    

                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
