<?php

namespace App\Http\Controllers;

use App\Models\category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use App\Models\product;


class productcontroller extends Controller
{
    //
    public function index(){
        $product=category::get();
        //dd($product);
        return view('/Product',compact('product'));
    }


    public function store(Request $request)
    {
           // $values=$request->all();

            //for validation
            $this->validate($request,[
                'product_category_name'=>'required'
                
            ]);
            //end of validation
            $product=new product;
            $product->product_category_name=$request->input('product_category_name');
            $product->product_category_description=$request->input('product_category_description');
           
            //for join two table
            
            //end of join
           
            if($request->hasfile('product_image'))
            {
            $filename=time().".".$request->file('product_image')->getClientOriginalExtension();
            $request->file('product_image')->move('uploads',$filename);
            // $values['product_image'] = $filename;
           $product->product_image=$filename;
            }
            $product->category_id=$request->input('category_id');
            $product->save();
            //$product=product::create($values);
            if($product)
            {
                toastr()->success('Record is added');
                return redirect('/product_list');
            }
    }


    public function show_table(){
        $products = product::join('categories','categories.category_id','products.category_id')->get();
        //$products=product::get();
        return view('product_list',compact('products'));
    }

    public function edit($id)
    {
        $product=product::findorfail($id);
        return view('edit_product',compact('product'));
    }

    public function update(Request $request)
    {
        $input=$request->all();
        $searchInput['product_category_id']=$input['product_category_id'];
        product::updateorcreate($searchInput,$input);
        toastr()->success('Record is updated');
        return redirect('/product_list');

    }

    public function destroy($id)
    {
        $product=product::find($id);
        $destination='uploads'.$product->product_image;
        //unlink($destination);
        if(File::exists($destination))
        {
            File::delete($destination);
        }
        $product->delete();
        //product::where('product_category_id',$id)->delete();
        toastr()->error('Record is deleted');
        return redirect('/product_list');
        // dd($id);
    }
}
