<?php

namespace App\Http\Controllers;

use App\Models\category;
use Illuminate\Http\Request;

class categoryController extends Controller
{
    //
    public function index(){
        return view('/category');
    }



    public function store(Request $request)
    {
            $values=$request->all();

            //for validation
            $this->validate($request,[
                'category_name'=>'required'
                
            ]);
            //end of validation
           // $product=product::create($values);
            //  dd($product);
            $product=new category;
            $product->category_name=$request->input('category_name');
            
            $product->save();
            if($product)
            {
                toastr()->success('Record is added');
                return redirect('/category_list');
            }
    }


    public function show_table()
    {
        $produc=category::get();
        return view('category_list',compact('produc'));
    }




    public function edit($id)
    {
        $product=category::findorfail($id);
        return view('edit_category',compact('product'));
    }

    public function update(Request $request)
    {
        $input=$request->all();
        $searchInput['category_id']=$input['category_id'];
        category::updateorcreate($searchInput,$input);
        toastr()->success('Record is updated');
        return redirect('/category_list');

    }

    public function destroy($id)
    {
        $product=category::find($id);
        // $destination='uploads'.$product->product_image;
        // //unlink($destination);
        // if(File::exists($destination))
        // {
        //     File::delete($destination);
        // }
        $product->delete();
        //product::where('product_category_id',$id)->delete();
        toastr()->error('Record is deleted');
        return redirect('/category_list');
        // dd($id);
    }
}
