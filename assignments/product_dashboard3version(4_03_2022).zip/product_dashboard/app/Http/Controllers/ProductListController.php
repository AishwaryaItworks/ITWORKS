<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\product;

class ProductListController extends Controller
{
    //
    public function index(){
        return view('product_list');
    }
    public function store(Request $request)
    {
            $values=$request->all();

            //for validation
            $this->validate($request,[
                'product_category_name'=>'required'
                
            ]);
            //end of validation
            $product=Product::create($values);
            //  dd($product);
            if($product)
            {
                // toastr()->success('Record is added');
                return redirect('product');
            }
    }
}
