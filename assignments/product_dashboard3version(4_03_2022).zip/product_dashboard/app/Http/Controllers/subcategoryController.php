<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Subcategory;
use App\Models\category;

class subcategoryController extends Controller
{
    //
    public function index(){
        $product=category::get();
        return view('subcategory',compact('product'));
    }

    public function store(Request $request)
    {
            $values=$request->all();

            //for validation
            $this->validate($request,[
                'subcategory_name'=>'required'
                
            ]);
            //end of validation
           // $product=product::create($values);
            //  dd($product);
            $product=new Subcategory;
            $product->category_id=$request->input('category_id');
            $product->subcategory_name=$request->input('subcategory_name');
           
            $product->save();
            if($product)
            {
                toastr()->success('Record is added');
                return redirect('/subcategory_list');
            }
    }


    public function show_table()
    {
        //$produc=Subcategory::get();
        $produc = Subcategory::join('categories','categories.category_id','subcategories.category_id')->get();
        return view('subcategory_list',compact('produc'));
    }


    public function edit($id)
    {
        $product=Subcategory::findorfail($id);
        return view('edit_subcategory',compact('product'));
    }

    public function update(Request $request)
    {
        $input=$request->all();
        $searchInput['subcategory_id']=$input['subcategory_id'];
        Subcategory::updateorcreate($searchInput,$input);
        toastr()->success('Record is updated');
        return redirect('/subcategory_list');

    }

    public function destroy($id)
    {
        $product=Subcategory::find($id);
        // $destination='uploads'.$product->product_image;
        // //unlink($destination);
        // if(File::exists($destination))
        // {
        //     File::delete($destination);
        // }
        $product->delete();
        //product::where('product_category_id',$id)->delete();
        toastr()->error('Record is deleted');
        return redirect('/subcategory_list');
        // dd($id);
    }
}
