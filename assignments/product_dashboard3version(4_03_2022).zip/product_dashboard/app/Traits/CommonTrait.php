<?php
namespace App\Traits;
use App\Models\category;

trait CommonTrait {
    public function getCategory($category_id) {
        $category = category::where('category_id',$category_id)->first();
        return $category;
    }
    
}
?>