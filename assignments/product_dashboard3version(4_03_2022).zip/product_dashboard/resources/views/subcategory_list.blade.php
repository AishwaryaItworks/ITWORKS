@extends('layouts.main')
@section('main-section')
<div class="page-breadcrumb bg-white">
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h4 class="page-title">Category</h4>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Category</div>

                <div class="card-body">
        <table class="table">
            <thead class="table-dark">
                <td>Category_Name</td>
                <td>SubCategory_Name</td>
                <td>Action</td>
            </thead>
            <tbody>
               @if($produc->isNotEmpty()) 
                    @foreach($produc as $product)
                    <tr>
                        {{-- <td>{{$product->product_category_id}}</td> --}}
                        <td>{{$product->category_name}}</td>
                        <td>{{$product->subcategory_name}}</td>

                        <td><a href="{{url('subcategory/edit')}}/{{$product->subcategory_id}}" class="btn btn-primary">Update</a>
                            <a href="{{url('subcategory/delete')}}/{{$product->subcategory_id}}" class="btn btn-danger">Delete</a></td>
                        
                    </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
       
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
@endsection