@extends('layouts.main')
@section('main-section')
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <h4 class="page-title">SubCategories</h4>
                <br>
            </div>
            <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                <div class="d-md-flex">
                    <ol class="breadcrumb ms-auto">
                        {{-- <li><a href="#" class="fw-normal">Dashboard</a></li> --}}
                    </ol>
                    {{-- <a href="{{url('/product_list')}}" target="_blank"
                        class="btn btn-danger  d-none d-md-block pull-right ms-3 hidden-xs hidden-sm waves-effect waves-light text-white">
                        View List of Product</a> --}}
                </div>
            </div>
            
        </div>

        <form action="{{url('subcategory/store')}}" method="post" enctype="multipart/form-data">
            @csrf

            <div class="form-group">
                <label>Select Category</label>
                <select name="category_id" class="form-control ">
                    <option value="">Select name</option>
                    @foreach($product as $category)
                    <option value="{{$category->category_id}}">{{$category->category_name}}</option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
            <label>Subcategory Name</label>
            <input type="text" class="form-control" name="subcategory_name" value="{{old('subcategory_name')}}">
            <small class="text-danger">{{$errors->first('subcategory_name')}}</small>
            </div>

            
            
            <div class="form-group">
                <input type="submit" class="btn btn-primary" name="submit" value="Add SubCategory">
            </div>


        </form>
        
    </div>
</div>


@endsection