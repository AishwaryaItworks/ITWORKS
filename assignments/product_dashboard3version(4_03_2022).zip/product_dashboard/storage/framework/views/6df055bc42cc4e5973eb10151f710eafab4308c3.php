
<?php $__env->startSection('main-section'); ?>
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <h4 class="page-title">SubCategories</h4>
                <br>
            </div>
            <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                <div class="d-md-flex">
                    <ol class="breadcrumb ms-auto">
                        
                    </ol>
                    
                </div>
            </div>
            
        </div>

        <form action="<?php echo e(url('subcategory/store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>Select Category</label>
                <select name="category_id" class="form-control ">
                    <option value="">Select name</option>
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->category_id); ?>"><?php echo e($category->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
            <label>Subcategory Name</label>
            <input type="text" class="form-control" name="subcategory_name" value="<?php echo e(old('subcategory_name')); ?>">
            <small class="text-danger"><?php echo e($errors->first('subcategory_name')); ?></small>
            </div>

            
            
            <div class="form-group">
                <input type="submit" class="btn btn-primary" name="submit" value="Add SubCategory">
            </div>


        </form>
        
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\product_dashboard\resources\views/subcategory.blade.php ENDPATH**/ ?>