
<?php $__env->startSection('main-section'); ?>
<div class="page-breadcrumb bg-white">
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h4 class="page-title">Category</h4>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Category</div>

                <div class="card-body">
        <table class="table">
            <thead class="table-dark">
                <td>Category_Name</td>
                <td>SubCategory_Name</td>
                <td>Action</td>
            </thead>
            <tbody>
               <?php if($produc->isNotEmpty()): ?> 
                    <?php $__currentLoopData = $produc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($product->category_name); ?></td>
                        <td><?php echo e($product->subcategory_name); ?></td>

                        <td><a href="<?php echo e(url('subcategory/edit')); ?>/<?php echo e($product->subcategory_id); ?>" class="btn btn-primary">Update</a>
                            <a href="<?php echo e(url('subcategory/delete')); ?>/<?php echo e($product->subcategory_id); ?>" class="btn btn-danger">Delete</a></td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
       
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\product_dashboard\resources\views/subcategory_list.blade.php ENDPATH**/ ?>