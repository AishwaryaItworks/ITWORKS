@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Products</div>

                <div class="card-body">
                    <form action="{{url('product/update')}}" method="post">
                        @csrf
                        <input type="hidden" name="product_category_id" value="{{$product->product_category_id}}">
                        <div class="form-group">
                        <label>Product Category Name</label>
                        <input type="text" class="form-control" name="product_category_name" value="{{$product->product_category_name}}">
                        <small class="text-danger">{{$errors->first('product_category_name')}}</small>
                        </div>

                        <div class="form-group">
                            <label>Product Description</label>
                            <textarea class="form-control" name="product_category_description" value="{{$product->product_category_description}}"></textarea>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="submit" value="update">
                        </div>
    

                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
