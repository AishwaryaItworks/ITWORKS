@extends('layouts.app')

@section('content-section')

<h1>hi</h1>

@endsection