@extends('layouts.main')
@section('main-section')
<div class="page-breadcrumb bg-white">
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h4 class="page-title">Products</h4>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Products</div>

                <div class="card-body">
        <table class="table">
            <thead>
                {{-- <td>Category_Id</td> --}}
                <td>Category_Name</td>
                <td>Category_Description</td>
                <td>Status</td>
                <td>Action</td>
            </thead>
            <tbody>
               @if($products->isNotEmpty()) 
                    @foreach($products as $product)
                    <tr>
                        {{-- <td>{{$product->product_category_id}}</td> --}}
                        <td>{{$product->product_category_name}}</td>
                        <td>{{$product->product_category_description}}</td>
                        <td>{{$product->product_category_status}}</td>
                        <td><a href="{{url('Product/edit')}}/{{$product->product_category_id}}" class="btn btn-primary">Update</a>
                            <a href="{{url('Product/delete')}}/{{$product->product_category_id}}" class="btn btn-danger">Delete</a></td>
                    </tr>
                    @endforeach
                @endif
            </tbody>
        </table>
       
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
@endsection