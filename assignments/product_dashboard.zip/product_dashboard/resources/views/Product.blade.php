@extends('layouts.main')
@section('main-section')
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <h4 class="page-title">Products</h4>
                <br>
            </div>
            <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                <div class="d-md-flex">
                    <ol class="breadcrumb ms-auto">
                        {{-- <li><a href="#" class="fw-normal">Dashboard</a></li> --}}
                    </ol>
                    {{-- <a href="{{url('/product_list')}}" target="_blank"
                        class="btn btn-danger  d-none d-md-block pull-right ms-3 hidden-xs hidden-sm waves-effect waves-light text-white">
                        View List of Product</a> --}}
                </div>
            </div>
            
        </div>

        <form action="{{url('Product/store')}}" method="post">
            @csrf
            <div class="form-group">
            <label>Product Category Name</label>
            <input type="text" class="form-control" name="product_category_name" value="{{old('product_category_name')}}">
            <small class="text-danger">{{$errors->first('product_category_name')}}</small>
            </div>

            <div class="form-group">
                <label>Product Description</label>
                <textarea class="form-control" name="product_category_description"></textarea>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" name="submit" value="Add Product">
            </div>


        </form>
        
    </div>
</div>
@endsection