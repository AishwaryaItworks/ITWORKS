<?php

use Illuminate\Support\Facades\Route;
use App\Models\productcontroller;
use App\Models\ProductListController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/Product', [App\Http\Controllers\productcontroller::class, 'index']);
// Route::get('/product_list', [App\Http\Controllers\productcontroller::class, 'index']);

// Route::get('/product_list', [App\Http\Controllers\ProductListController::class, 'index']);
Route::get('/product_list', [App\Http\Controllers\productcontroller::class, 'show_table']);
Route::post('/Product/store', [App\Http\Controllers\productcontroller::class, 'store']);
Route::get('/Product/delete/{id}', [App\Http\Controllers\productcontroller::class, 'destroy']);

Route::get('/Product/edit/{id}', [App\Http\Controllers\productcontroller::class, 'edit']);

Route::post('/Product/update', [App\Http\Controllers\productcontroller::class, 'update']);

