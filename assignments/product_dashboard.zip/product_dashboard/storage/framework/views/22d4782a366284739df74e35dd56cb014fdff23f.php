
<?php $__env->startSection('main-section'); ?>
<div class="page-wrapper">
    <div class="page-breadcrumb bg-white">
        <div class="row align-items-center">
            <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                <h4 class="page-title">Products</h4>
                <br>
            </div>
            <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                <div class="d-md-flex">
                    <ol class="breadcrumb ms-auto">
                        
                    </ol>
                    
                </div>
            </div>
            
        </div>

        <form action="<?php echo e(url('Product/store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
            <label>Product Category Name</label>
            <input type="text" class="form-control" name="product_category_name" value="<?php echo e(old('product_category_name')); ?>">
            <small class="text-danger"><?php echo e($errors->first('product_category_name')); ?></small>
            </div>

            <div class="form-group">
                <label>Product Description</label>
                <textarea class="form-control" name="product_category_description"></textarea>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" name="submit" value="Add Product">
            </div>


        </form>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\product_dashboard\resources\views//Product.blade.php ENDPATH**/ ?>