
<?php $__env->startSection('main-section'); ?>
<div class="page-breadcrumb bg-white">
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h4 class="page-title">Products</h4>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Products</div>

                <div class="card-body">
        <table class="table">
            <thead>
                
                <td>Category_Name</td>
                <td>Category_Description</td>
                <td>Status</td>
                <td>Action</td>
            </thead>
            <tbody>
               <?php if($products->isNotEmpty()): ?> 
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($product->product_category_name); ?></td>
                        <td><?php echo e($product->product_category_description); ?></td>
                        <td><?php echo e($product->product_category_status); ?></td>
                        <td><a href="<?php echo e(url('Product/edit')); ?>/<?php echo e($product->product_category_id); ?>" class="btn btn-primary">Update</a>
                            <a href="<?php echo e(url('Product/delete')); ?>/<?php echo e($product->product_category_id); ?>" class="btn btn-danger">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
       
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\product_dashboard\resources\views/product_list.blade.php ENDPATH**/ ?>