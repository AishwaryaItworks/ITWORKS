<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\product;

class productcontroller extends Controller
{
    //
    public function index(){
        return view('/Product');
    }


    public function store(Request $request)
    {
            $values=$request->all();

            //for validation
            $this->validate($request,[
                'product_category_name'=>'required'
                
            ]);
            //end of validation
            $product=product::create($values);
            //  dd($product);
            if($product)
            {
                toastr()->success('Record is added');
                return redirect('/product_list');
            }
    }


    public function show_table(){
        $products=product::get();
        return view('product_list',compact('products'));
    }

    public function edit($id)
    {
        $product=product::findorfail($id);
        return view('edit_product',compact('product'));
    }

    public function update(Request $request)
    {
        $input=$request->all();
        $searchInput['product_category_id']=$input['product_category_id'];
        product::updateorcreate($searchInput,$input);
        toastr()->success('Record is updated');
        return redirect('/product_list');

    }

    public function destroy($id)
    {
        product::where('product_category_id',$id)->delete();
        toastr()->error('Record is deleted');
        return redirect('/product_list');
        // dd($id);
    }
}
